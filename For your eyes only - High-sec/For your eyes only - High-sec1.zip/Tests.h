#pragma once
#include "Recording.h"
#include "Repository.h"
#include "Business.h"
#include "RepositoryFromTxt.h"
void runAllTests();