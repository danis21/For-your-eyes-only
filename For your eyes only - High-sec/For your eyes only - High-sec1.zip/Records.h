#pragma once
#include "Recording.h"

class Records
{
private:
	vector<Record> records;
	vector<Record>::iterator iterator = records.begin();

public:
	void add(const Record& record);

	vector<Record> get_all();
	int get_size();

	Record& operator[](int position);
};