using namespace std;
#include <assert.h>
#include "Tests.h"
#include <iostream>
#include <crtdbg.h>
//Record
void getTitle_ValidRecord_returnTitle()
{
	Date timeOfCreation(10, 10, 2000);
	Record record{ "Title", "location", timeOfCreation, 10, "footage" };
	assert(record.getTitle() == "Title");
}
void getLocation_ValidRecord_returnLocation()
{
	Date timeOfCreation(10, 10, 2000);
	Record record{ "Title", "location", timeOfCreation, 10, "footage" };
	assert(record.getLocation() == "location");
}

void getTimesAccessed_ValidRecord_returnTimesAccessed()
{
	Date timeOfCreation(10, 10, 2000);
	Record record{ "Title", "location", timeOfCreation, 10, "footage" };
	assert(record.getTimesAccessed() == 10);
}
void getFootagePreview_ValidRecord_returnFootagePreview()
{
	Date timeOfCreation(10, 10, 2000);
	Record record{ "Title", "location", timeOfCreation, 10, "footage" };
	assert(record.getFootagePreview() == "footage");
}

//Repository

void addRecord_ValidRecord_AddsToList()
{
	FileRepository repository{};
	vector<Record> records = repository.getRecords();
	Date timeOfCreation(10, 10, 2000);
	Record record{ "Title", "location", timeOfCreation, 10, "footage" };
	repository.addRecord(record);

	assert(repository.getRecords().size() == 1);
}

void deleteRecord_ValidRecord_RemovesFromList()
{
	FileRepository repository{};
	vector<Record> records = repository.getRecords();
	Date timeOfCreation(10, 10, 2000);
	Record record{ "Title", "location", timeOfCreation, 10, "footage" };
	repository.addRecord(record);
	repository.deleteRecord("Title");

	assert(repository.getRecords().size() == 0);
}

void updateRecord_ValidRecord_UpdateAnRecordFromList()
{
	FileRepository repository{};
	vector<Record> records = repository.getRecords();
	Date timeOfCreation(10, 10, 2000);
	Record record{ "Title", "location", timeOfCreation, 10, "footage" };
	Date newtimeOfCreation(10, 10, 2000);
	Record newrecord{ "Title", "locatdfsion", newtimeOfCreation, 13, "dsa" };
	repository.addRecord(record);
	repository.updateRecord(newrecord);

	assert(repository.getRecords().size() == 1);
}

void isExisting_ValidTitle_ValidateTheIDofAnRecord()
{
	FileRepository repository{};
	Business business{ repository };

	std::string title = "Title";

	assert(business.isExisting(title) == 0);
}

void next_ValidRepository_GetTheNextRecord()
{
	FileRepository repository{};
	Date timeOfCreation(10, 10, 2000);
	Record record{ "Title", "location", timeOfCreation, 10, "footage" };
	Date newtimeOfCreation(10, 10, 2000);
	Record newrecord{ "Title", "location", newtimeOfCreation, 10, "footage" };
	repository.addRecord(record);
	repository.addRecord(newrecord);

	repository.next();
	assert(repository.getRecord() == newrecord);
}

void getRecord_ValidRepository_GetCurrentRecord()
{
	FileRepository repository{};
	Date timeOfCreation(10, 10, 2000);
	Record record{ "Title", "location", timeOfCreation, 10, "footage" };
	Date newtimeOfCreation(10, 10, 2000);
	Record newrecord{ "Title", "location", newtimeOfCreation, 10, "footage" };
	repository.addRecord(record);
	repository.addRecord(newrecord);

	repository.next();
	assert(repository.getRecord() == newrecord);
}


void savedRecords_ValidRecord_recordAddedToSecondRepository()
{
	FileRepository repository;
	Business business{ repository };
	Date timeOfCreation(10, 10, 2000);
	Record record{ "Title", "location", timeOfCreation, 10, "footage" };

	business.addNewRecording("a", "B", 10, 10, 2000, 2, "d");
	business.save("a");
	assert(business.getAllSavedRecords()[0] == record);
}

void filterByLocation_serviceWithMatches_returnsMatches()
{
	FileRepository repository;
	Business service{ repository };
	Date timeOfCreation(10, 10, 2000);
	Record match{ "z", "y", timeOfCreation, 8, "x" };

	service.addNewRecording("a", "b", 10, 10, 2000, 2, "c");
	service.addNewRecording("z", "y", 9, 1, 10, 8, "x");
	service.addNewRecording("c", "y", 1, 1, 10, 1, "e");

	assert(service.getFilteredRecords("y", 5)[0] == match);
}

void filterByLocation_serviceWithNoMatches_throwsException()
{
	FileRepository repository;
	Business business{ repository };

	business.addNewRecording("a", "b", 1, 1, 10, 8, "c");
	business.addNewRecording("z", "y", 9, 1, 10, 2, "x");

	try { vector<Record> filtered_list = business.getFilteredRecords("y", 5); }
	catch (const char* message) {
		assert(strcmp(message, "No matching turrets") == 0);
	}
}
/*
void begin_ofADynamicVector_pointerToFirstElement()
{
	vector<int> vector{};
	vector.push_back(1);
	vector<int>::Iterator iterator = vector.begin();
	assert(*iterator == vector[0]);
}
*/
/*
void addOperator_iterator_isIncremented()
{
	DynamicVector<int> vector{};
	vector.add(1);
	vector.add(2);
	DynamicVector<int>::Iterator iterator = vector.begin();
	++iterator;
	assert(*iterator == vector[1]);
}
*/
void runAllTests() {
	getTitle_ValidRecord_returnTitle();
	getLocation_ValidRecord_returnLocation();
	getLocation_ValidRecord_returnLocation();
	getTimesAccessed_ValidRecord_returnTimesAccessed();
	getFootagePreview_ValidRecord_returnFootagePreview();
	addRecord_ValidRecord_AddsToList();
	deleteRecord_ValidRecord_RemovesFromList();
	updateRecord_ValidRecord_UpdateAnRecordFromList();
	isExisting_ValidTitle_ValidateTheIDofAnRecord();
	next_ValidRepository_GetTheNextRecord();
	getRecord_ValidRepository_GetCurrentRecord();
	//addOperator_iterator_isIncremented();
	//begin_ofADynamicVector_pointerToFirstElement();
	filterByLocation_serviceWithNoMatches_throwsException();
}