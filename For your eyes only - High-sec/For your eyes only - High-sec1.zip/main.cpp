#include "Recording.h"
#include "Repository.h"
#include "Business.h"
#include "UI.h"
#include <crtdbg.h>
#include "Tests.h"
#include "RepositoryFromTxt.h"
int main()
{
	//runAllTests();

	FileRepository repository{};
	Business business{ repository };
	UI ui{ business };
	ui.mainMenu();

	_CrtDumpMemoryLeaks();
}