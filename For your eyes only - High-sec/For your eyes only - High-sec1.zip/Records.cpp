#include "Records.h"

void Records::add(const Record& record)
{
	this->records.push_back(record);
}

vector<Record> Records::get_all()
{
	return this->records;
}
int Records::get_size()
{
	return this->records.size();
}

Record& Records::operator[](int position)
{
	return this->records[position];
}