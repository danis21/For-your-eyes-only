#pragma once
#include "Recording.h"
#include "Business.h"
#include "RepositoryFromTxt.h"
void runAllTests();